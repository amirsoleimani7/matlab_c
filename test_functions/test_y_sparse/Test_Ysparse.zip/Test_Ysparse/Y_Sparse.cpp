#include "H_header.h"


using namespace Eigen;

MatrixXcf Y_Sparse(  NBus *NBusObj  , Line* lineArray)
{

    std::complex<float> j(0.0, 1.0);


    VectorXf Gb = NBusObj->getGbArray() ; // (number of busses ,1) -> (13 ,1)
    VectorXf Bb = NBusObj->getBbArray() ; // (number of busses ,1) -> (13 ,1)
    MatrixXcf Y = MatrixXcf::Zero(N, N); //(number of bus,number of bus)... -> (13 ,13)

    MatrixXf NLineMatrix = creatMatrixFromLineArray( lineArray ) ; //this is the number of lines , busses (14 ,13)

    //VectorXcf chrg = NLineMatrix.col(chrg_index) ;
    VectorXcf chrg = NLineMatrix.col(chrg_index).cast<std::complex<float>>(); // the dimention is (14 ,1)
    
    VectorXf r = NLineMatrix.col(r_index) ; // the dimention is (number of lines ,1) -> (14 ,1)

    VectorXf rx = NLineMatrix.col(rx_index);  // the dim is (14 ,1)

    VectorXf raw_tap = NLineMatrix.col(raw_tap_index) ; // the dim is (14 ,1)

    VectorXf phase_shift = NLineMatrix.col(phase_shift_index) ; // the dim is (14 ,1)

    
    
    chrg = (chrg.array()/2.0)*j ;  
    //chrg = chrg.array().inverse() ;

    DiagonalMatrix<std::complex<float>, NPrime> chrg_sparse(chrg);  // (thsi is 14 ,14 ) -> (number of lines , number of lines) ...


    VectorXcf z = r.array() + (rx.array()*j); //z is (14 ,1) -> (number of lines ,1)
 
    z = z.array().inverse() ; // z is (14 ,1) -> (numebr of lines ,1)
    //DiagonalMatrix<std::complex<float>, NPrime> y(z.cast<std::complex<float>>());
    DiagonalMatrix<std::complex<float>, NPrime> y(z);  // y is (14, 14) -> (numebr of lines , number of lines)

    VectorXf temp(NPrime) ;

    std::complex<float> tap[NPrime] ; 

    for(int i=0 ; i<NPrime ; i++)
    {
         temp[i] = 1 ;
         if( abs(raw_tap[i])<=0 )
         {
             temp[i] = inverse(raw_tap[i]);
         }
         tap[i] = polar(temp[i] ,degreeToRadians(phase_shift[i])) ;
    }

    //MatrixXf c_line = c_from - c_to ;
    
    //Y += c_to * chrg_sparse * c_to.transpose() ;
    //Y += c_from * chrg_sparse * c_from.transpose() ;
    //Y += c_line * y * c_line.transpose() ;
    
    MatrixXcf c_from = MatrixXcf::Zero(N, NPrime); //(13 ,14) -> (n_bus , n_line)
    MatrixXcf c_to = MatrixXcf::Zero(N, NPrime); //(13 ,14) -> (n_bus,n_line)
    for (int iline = 0; iline < NPrime; iline++) {
        int from = static_cast<int>(lineArray[iline].from_bus);
        int to = static_cast<int>(lineArray[iline].to_bus);
        if (from < N && to < N) {
            c_from(from, iline) = tap[iline];
            c_to(to, iline) = 1;
        }
    }


    MatrixXcf c_line = c_from.cast<std::complex<float>>() - c_to.cast<std::complex<float>>();

    Y += c_to.cast<std::complex<float>>() * chrg_sparse * c_to.cast<std::complex<float>>().transpose();
    Y += c_from.cast<std::complex<float>>() * chrg_sparse * c_from.cast<std::complex<float>>().transpose();
    Y += c_line * y * c_line.transpose();

    if( Y.isDiagonal() )
    {
      VectorXcf tmp = Bb.array()*j ;
      //Y += Gb + Bb ;
      Y += Gb.cast<std::complex<float>>().asDiagonal() + Bb.cast<std::complex<float>>().asDiagonal();

    } 

    return Y ;   

} 
