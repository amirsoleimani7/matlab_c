#ifndef Header_h
#define Header_h

#include<eigen3/Eigen/Core>
#include<iostream>
#include <cmath>
//#include<complex.h>
#include<vector>

#include"H_NBus.h"
#include"H_Line.h"
// #include "H_tg_con.h"
// #include "H_mac_con.h"

float inverse(float num) ;
float degreeToRadians( float degrees) ;
MatrixXcf Division_Two_Matrix(MatrixXcf A, MatrixXcf B);
MatrixXf creatMatrixFromLineArray( Line* lineArray ) ;
MatrixXcf Y_Sparse(  NBus *NBusObj  , Line* lineArray) ;

#endif